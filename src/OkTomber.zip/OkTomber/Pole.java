package OkTomber;

import battlecode.common.MapLocation;

public class Pole{
    public MapLocation map;
    public String head;
    public Pole(MapLocation m, String h){
        map = m;
        head = h;
    }
}
