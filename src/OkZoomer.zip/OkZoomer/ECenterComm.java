package OkZoomer;

import battlecode.common.*;

public class ECenterComm {

    public RobotController rc;

    public ECenterComm(RobotController r) {
        rc = r;
    }

}
