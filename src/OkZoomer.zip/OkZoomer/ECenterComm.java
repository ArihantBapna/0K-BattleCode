package OkZoomer;

import battlecode.common.RobotController;

public class ECenterComm {

    public RobotController rc;

    public ECenterComm(RobotController r) {
        rc = r;
    }

}
